(()=>{var a={};a.id=4174,a.ids=[4174],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},26713:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/is-bot")},28354:a=>{"use strict";a.exports=require("util")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},37590:(a,b,c)=>{"use strict";c.d(b,{l$:()=>Z,Ay:()=>$,oR:()=>B});var d,e=c(43210);let f={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,i=/\n+/g,j=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?j(g,f):f+"{"+j(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=j(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f=/^--/.test(f)?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=j.p?j.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},k={},l=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+l(a[c]);return b}return a};function m(a){let b,c,d,e=this||{},m=a.call?a(e.p):a;return((a,b,c,d,e)=>{var f,m,n,o;let p=l(a),q=k[p]||(k[p]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(p));if(!k[q]){let b=p!==a?a:(a=>{let b,c,d=[{}];for(;b=g.exec(a.replace(h,""));)b[4]?d.shift():b[3]?(c=b[3].replace(i," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(i," ").trim();return d[0]})(a);k[q]=j(e?{["@keyframes "+q]:b}:b,c?"":"."+q)}let r=c&&k.g?k.g:null;return c&&(k.g=k[q]),f=k[q],m=b,n=d,(o=r)?m.data=m.data.replace(o,f):-1===m.data.indexOf(f)&&(m.data=n?f+m.data:m.data+f),q})(m.unshift?m.raw?(b=[].slice.call(arguments,1),c=e.p,m.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":j(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):m.reduce((a,b)=>Object.assign(a,b&&b.call?b(e.p):b),{}):m,(d=e.target,"object"==typeof window?((d?d.querySelector("#_goober"):window._goober)||Object.assign((d||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:d||f),e.g,e.o,e.k)}m.bind({g:1});let n,o,p,q=m.bind({k:1});function r(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:o&&o()},h),c.o=/ *go\d+/.test(i),h.className=m.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),p&&j[0]&&p(h),n(j,h)}return b?b(e):e}}var s=(a,b)=>"function"==typeof a?a(b):a,t=(()=>{let a=0;return()=>(++a).toString()})(),u=(()=>{let a;return()=>a})(),v=(a,b)=>{switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,20)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:c}=b;return v(a,{type:+!!a.toasts.find(a=>a.id===c.id),toast:c});case 3:let{toastId:d}=b;return{...a,toasts:a.toasts.map(a=>a.id===d||void 0===d?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let e=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+e}))}}},w=[],x={toasts:[],pausedAt:void 0},y=a=>{x=v(x,a),w.forEach(a=>{a(x)})},z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},A=a=>(b,c)=>{let d=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||t()}))(b,a,c);return y({type:2,toast:d}),d.id},B=(a,b)=>A("blank")(a,b);B.error=A("error"),B.success=A("success"),B.loading=A("loading"),B.custom=A("custom"),B.dismiss=a=>{y({type:3,toastId:a})},B.remove=a=>y({type:4,toastId:a}),B.promise=(a,b,c)=>{let d=B.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?s(b.success,a):void 0;return e?B.success(e,{id:d,...c,...null==c?void 0:c.success}):B.dismiss(d),a}).catch(a=>{let e=b.error?s(b.error,a):void 0;e?B.error(e,{id:d,...c,...null==c?void 0:c.error}):B.dismiss(d)}),a};var C=(a,b)=>{y({type:1,toast:{id:a,height:b}})},D=()=>{y({type:5,time:Date.now()})},E=new Map,F=1e3,G=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,H=q`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,I=q`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,J=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${G} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${H} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,K=q`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,L=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${K} 1s linear infinite;
`,M=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,N=q`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,O=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${M} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${N} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,P=r("div")`
  position: absolute;
`,Q=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,R=q`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,S=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${R} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,T=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?e.createElement(S,null,b):b:"blank"===c?null:e.createElement(Q,null,e.createElement(L,{...d}),"loading"!==c&&e.createElement(P,null,"error"===c?e.createElement(J,{...d}):e.createElement(O,{...d})))},U=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,V=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,W=e.memo(({toast:a,position:b,style:c,children:d})=>{let f=a.height?((a,b)=>{let c=a.includes("top")?1:-1,[d,e]=u()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*c}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*c}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${q(d)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${q(e)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},g=e.createElement(T,{toast:a}),h=e.createElement(V,{...a.ariaProps},s(a.message,a));return e.createElement(U,{className:a.className,style:{...f,...c,...a.style}},"function"==typeof d?d({icon:g,message:h}):e.createElement(e.Fragment,null,g,h))});d=e.createElement,j.p=void 0,n=d,o=void 0,p=void 0;var X=({id:a,className:b,style:c,onHeightUpdate:d,children:f})=>{let g=e.useCallback(b=>{if(b){let c=()=>{d(a,b.getBoundingClientRect().height)};c(),new MutationObserver(c).observe(b,{subtree:!0,childList:!0,characterData:!0})}},[a,d]);return e.createElement("div",{ref:g,className:b,style:c},f)},Y=m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,Z=({reverseOrder:a,position:b="top-center",toastOptions:c,gutter:d,children:f,containerStyle:g,containerClassName:h})=>{let{toasts:i,handlers:j}=(a=>{let{toasts:b,pausedAt:c}=((a={})=>{let[b,c]=(0,e.useState)(x),d=(0,e.useRef)(x);(0,e.useEffect)(()=>(d.current!==x&&c(x),w.push(c),()=>{let a=w.indexOf(c);a>-1&&w.splice(a,1)}),[]);let f=b.toasts.map(b=>{var c,d,e;return{...a,...a[b.type],...b,removeDelay:b.removeDelay||(null==(c=a[b.type])?void 0:c.removeDelay)||(null==a?void 0:a.removeDelay),duration:b.duration||(null==(d=a[b.type])?void 0:d.duration)||(null==a?void 0:a.duration)||z[b.type],style:{...a.style,...null==(e=a[b.type])?void 0:e.style,...b.style}}});return{...b,toasts:f}})(a);(0,e.useEffect)(()=>{if(c)return;let a=Date.now(),d=b.map(b=>{if(b.duration===1/0)return;let c=(b.duration||0)+b.pauseDuration-(a-b.createdAt);if(c<0){b.visible&&B.dismiss(b.id);return}return setTimeout(()=>B.dismiss(b.id),c)});return()=>{d.forEach(a=>a&&clearTimeout(a))}},[b,c]);let d=(0,e.useCallback)(()=>{c&&y({type:6,time:Date.now()})},[c]),f=(0,e.useCallback)((a,c)=>{let{reverseOrder:d=!1,gutter:e=8,defaultPosition:f}=c||{},g=b.filter(b=>(b.position||f)===(a.position||f)&&b.height),h=g.findIndex(b=>b.id===a.id),i=g.filter((a,b)=>b<h&&a.visible).length;return g.filter(a=>a.visible).slice(...d?[i+1]:[0,i]).reduce((a,b)=>a+(b.height||0)+e,0)},[b]);return(0,e.useEffect)(()=>{b.forEach(a=>{if(a.dismissed)((a,b=F)=>{if(E.has(a))return;let c=setTimeout(()=>{E.delete(a),y({type:4,toastId:a})},b);E.set(a,c)})(a.id,a.removeDelay);else{let b=E.get(a.id);b&&(clearTimeout(b),E.delete(a.id))}})},[b]),{toasts:b,handlers:{updateHeight:C,startPause:D,endPause:d,calculateOffset:f}}})(c);return e.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...g},className:h,onMouseEnter:j.startPause,onMouseLeave:j.endPause},i.map(c=>{let g=c.position||b,h=((a,b)=>{let c=a.includes("top"),d=a.includes("center")?{justifyContent:"center"}:a.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:u()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${b*(c?1:-1)}px)`,...c?{top:0}:{bottom:0},...d}})(g,j.calculateOffset(c,{reverseOrder:a,gutter:d,defaultPosition:b}));return e.createElement(X,{id:c.id,key:c.id,onHeightUpdate:j.updateHeight,className:c.visible?Y:"",style:h},"custom"===c.type?s(c.message,c):f?f(c):e.createElement(W,{toast:c,position:g}))}))},$=B},41025:a=>{"use strict";a.exports=require("next/dist/server/app-render/dynamic-access-async-storage.external.js")},42490:(a,b,c)=>{Promise.resolve().then(c.bind(c,92341))},45524:(a,b,c)=>{"use strict";c.r(b),c.d(b,{GlobalError:()=>C.a,__next_app__:()=>I,handler:()=>K,pages:()=>H,routeModule:()=>J,tree:()=>G});var d=c(65239),e=c(48088),f=c(47220),g=c(81289),h=c(26191),i=c(14823),j=c(71998),k=c(92603),l=c(54649),m=c(32781),n=c(82602),o=c(61268),p=c(4853),q=c(261),r=c(5052),s=c(9977),t=c(26713),u=c(43365),v=c(71454),w=c(67778),x=c(46143),y=c(39105),z=c(38171),A=c(86439),B=c(16133),C=c.n(B),D=c(30893),E=c(52836),F={};for(let a in D)0>["default","tree","pages","GlobalError","__next_app__","routeModule","handler"].indexOf(a)&&(F[a]=()=>D[a]);c.d(b,F);let G={children:["",{children:["registration",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(c.bind(c,92341)),"C:\\Users\\Getahun\\Desktop\\projects\\kidney\\app\\registration\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(c.bind(c,58014)),"C:\\Users\\Getahun\\Desktop\\projects\\kidney\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(c.bind(c,82366)),"C:\\Users\\Getahun\\Desktop\\projects\\kidney\\app\\not-found.tsx"],"global-error":[()=>Promise.resolve().then(c.t.bind(c,16133,23)),"next/dist/client/components/builtin/global-error.js"],forbidden:[()=>Promise.resolve().then(c.t.bind(c,29868,23)),"next/dist/client/components/builtin/forbidden.js"],unauthorized:[()=>Promise.resolve().then(c.t.bind(c,79615,23)),"next/dist/client/components/builtin/unauthorized.js"]}]}.children,H=["C:\\Users\\Getahun\\Desktop\\projects\\kidney\\app\\registration\\page.tsx"],I={require:c,loadChunk:()=>Promise.resolve()},J=new d.AppPageRouteModule({definition:{kind:e.RouteKind.APP_PAGE,page:"/registration/page",pathname:"/registration",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:G},distDir:".next",projectDir:""});async function K(a,b,c){var d;let B="/registration/page";"/index"===B&&(B="/");let F="false",L=(0,h.getRequestMeta)(a,"postponed"),M=(0,h.getRequestMeta)(a,"minimalMode"),N=await J.prepare(a,b,{srcPage:B,multiZoneDraftMode:F});if(!N)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:O,query:P,params:Q,parsedUrl:R,pageIsDynamic:S,buildManifest:T,nextFontManifest:U,reactLoadableManifest:V,serverActionsManifest:W,clientReferenceManifest:X,subresourceIntegrityManifest:Y,prerenderManifest:Z,isDraftMode:$,resolvedPathname:_,revalidateOnlyGenerated:aa,routerServerContext:ab,nextConfig:ac}=N,ad=R.pathname||"/",ae=(0,q.normalizeAppPath)(B),{isOnDemandRevalidate:af}=N,ag=Z.dynamicRoutes[ae],ah=Z.routes[_],ai=!!(ag||ah||Z.routes[ae]),aj=a.headers["user-agent"]||"",ak=(0,t.getBotType)(aj),al=(0,o.isHtmlBotRequest)(a),am=(0,h.getRequestMeta)(a,"isPrefetchRSCRequest")??!!a.headers[s.NEXT_ROUTER_PREFETCH_HEADER],an=(0,h.getRequestMeta)(a,"isRSCRequest")??!!a.headers[s.RSC_HEADER],ao=(0,r.getIsPossibleServerAction)(a),ap=(0,l.checkIsAppPPREnabled)(ac.experimental.ppr)&&(null==(d=Z.routes[ae]??Z.dynamicRoutes[ae])?void 0:d.renderingMode)==="PARTIALLY_STATIC",aq=!1,ar=!1,as=ap?L:void 0,at=ap&&an&&!am,au=(0,h.getRequestMeta)(a,"segmentPrefetchRSCRequest"),av=!aj||(0,o.shouldServeStreamingMetadata)(aj,ac.htmlLimitedBots);al&&ap&&(ai=!1,av=!1);let aw=!0===J.isDev||!ai||"string"==typeof L||at,ax=al&&ap,ay=null;$||!ai||aw||ao||as||at||(ay=_);let az=ay;!az&&J.isDev&&(az=_);let aA={...D,tree:G,pages:H,GlobalError:C(),handler:K,routeModule:J,__next_app__:I};W&&X&&(0,n.setReferenceManifestsSingleton)({page:B,clientReferenceManifest:X,serverActionsManifest:W,serverModuleMap:(0,p.createServerModuleMap)({serverActionsManifest:W})});let aB=a.method||"GET",aC=(0,g.getTracer)(),aD=aC.getActiveScopeSpan();try{let d=async(c,d)=>{let e=new k.NodeNextRequest(a),f=new k.NodeNextResponse(b);return J.render(e,f,d).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=aC.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==i.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${aB} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${aB} ${a.url}`)})},f=async({span:e,postponed:f,fallbackRouteParams:g})=>{let i={query:P,params:Q,page:ae,sharedContext:{buildId:O},serverComponentsHmrCache:(0,h.getRequestMeta)(a,"serverComponentsHmrCache"),fallbackRouteParams:g,renderOpts:{App:()=>null,Document:()=>null,pageConfig:{},ComponentMod:aA,Component:(0,j.T)(aA),params:Q,routeModule:J,page:B,postponed:f,shouldWaitOnAllReady:ax,serveStreamingMetadata:av,supportsDynamicResponse:"string"==typeof f||aw,buildManifest:T,nextFontManifest:U,reactLoadableManifest:V,subresourceIntegrityManifest:Y,serverActionsManifest:W,clientReferenceManifest:X,setIsrStatus:null==ab?void 0:ab.setIsrStatus,dir:J.projectDir,isDraftMode:$,isRevalidate:ai&&!f&&!at,botType:ak,isOnDemandRevalidate:af,isPossibleServerAction:ao,assetPrefix:ac.assetPrefix,nextConfigOutput:ac.output,crossOrigin:ac.crossOrigin,trailingSlash:ac.trailingSlash,previewProps:Z.preview,deploymentId:ac.deploymentId,enableTainting:ac.experimental.taint,htmlLimitedBots:ac.htmlLimitedBots,devtoolSegmentExplorer:ac.experimental.devtoolSegmentExplorer,reactMaxHeadersLength:ac.reactMaxHeadersLength,multiZoneDraftMode:F,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:ac.experimental.cacheLife,basePath:ac.basePath,serverActions:ac.experimental.serverActions,...aq?{nextExport:!0,supportsDynamicResponse:!1,isStaticGeneration:!0,isRevalidate:!0,isDebugDynamicAccesses:aq}:{},experimental:{isRoutePPREnabled:ap,expireTime:ac.expireTime,staleTimes:ac.experimental.staleTimes,dynamicIO:!!ac.experimental.dynamicIO,clientSegmentCache:!!ac.experimental.clientSegmentCache,dynamicOnHover:!!ac.experimental.dynamicOnHover,inlineCss:!!ac.experimental.inlineCss,authInterrupts:!!ac.experimental.authInterrupts,clientTraceMetadata:ac.experimental.clientTraceMetadata||[]},waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:()=>{},onInstrumentationRequestError:(b,c,d)=>J.onRequestError(a,b,d,ab),err:(0,h.getRequestMeta)(a,"invokeError"),dev:J.isDev}},k=await d(e,i),{metadata:l}=k,{cacheControl:m,headers:n={},fetchTags:o}=l;if(o&&(n[x.NEXT_CACHE_TAGS_HEADER]=o),a.fetchMetrics=l.fetchMetrics,ai&&(null==m?void 0:m.revalidate)===0&&!J.isDev&&!ap){let a=l.staticBailoutInfo,b=Object.defineProperty(Error(`Page changed from static to dynamic at runtime ${_}${(null==a?void 0:a.description)?`, reason: ${a.description}`:""}
see more here https://nextjs.org/docs/messages/app-static-to-dynamic-error`),"__NEXT_ERROR_CODE",{value:"E132",enumerable:!1,configurable:!0});if(null==a?void 0:a.stack){let c=a.stack;b.stack=b.message+c.substring(c.indexOf("\n"))}throw b}return{value:{kind:u.CachedRouteKind.APP_PAGE,html:k,headers:n,rscData:l.flightData,postponed:l.postponed,status:l.statusCode,segmentData:l.segmentData},cacheControl:m}},l=async({hasResolved:d,previousCacheEntry:g,isRevalidating:i,span:j})=>{let k,l=!1===J.isDev,n=d||b.writableEnded;if(af&&aa&&!g&&!M)return(null==ab?void 0:ab.render404)?await ab.render404(a,b):(b.statusCode=404,b.end("This page could not be found")),null;if(ag&&(k=(0,v.parseFallbackField)(ag.fallback)),k===v.FallbackMode.PRERENDER&&(0,t.isBot)(aj)&&(k=v.FallbackMode.BLOCKING_STATIC_RENDER),(null==g?void 0:g.isStale)===-1&&(af=!0),af&&(k!==v.FallbackMode.NOT_FOUND||g)&&(k=v.FallbackMode.BLOCKING_STATIC_RENDER),!M&&k!==v.FallbackMode.BLOCKING_STATIC_RENDER&&az&&!n&&!$&&S&&(l||!ah)){let b;if((l||ag)&&k===v.FallbackMode.NOT_FOUND)throw new A.NoFallbackError;if(ap&&!an){if(b=await J.handleResponse({cacheKey:l?ae:null,req:a,nextConfig:ac,routeKind:e.RouteKind.APP_PAGE,isFallback:!0,prerenderManifest:Z,isRoutePPREnabled:ap,responseGenerator:async()=>f({span:j,postponed:void 0,fallbackRouteParams:l||ar?(0,m.u)(ae):null}),waitUntil:c.waitUntil}),null===b)return null;if(b)return delete b.cacheControl,b}}let o=af||i||!as?void 0:as;if(aq&&void 0!==o)return{cacheControl:{revalidate:1,expire:void 0},value:{kind:u.CachedRouteKind.PAGES,html:w.default.fromStatic(""),pageData:{},headers:void 0,status:void 0}};let p=S&&ap&&((0,h.getRequestMeta)(a,"renderFallbackShell")||ar)?(0,m.u)(ad):null;return f({span:j,postponed:o,fallbackRouteParams:p})},n=async d=>{var g,i,j,k,m;let n,o=await J.handleResponse({cacheKey:ay,responseGenerator:a=>l({span:d,...a}),routeKind:e.RouteKind.APP_PAGE,isOnDemandRevalidate:af,isRoutePPREnabled:ap,req:a,nextConfig:ac,prerenderManifest:Z,waitUntil:c.waitUntil});if($&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate"),J.isDev&&b.setHeader("Cache-Control","no-store, must-revalidate"),!o){if(ay)throw Object.defineProperty(Error("invariant: cache entry required but not generated"),"__NEXT_ERROR_CODE",{value:"E62",enumerable:!1,configurable:!0});return null}if((null==(g=o.value)?void 0:g.kind)!==u.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant app-page handler received invalid cache entry ${null==(j=o.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E707",enumerable:!1,configurable:!0});let p="string"==typeof o.value.postponed;ai&&!at&&(!p||am)&&(M||b.setHeader("x-nextjs-cache",af?"REVALIDATED":o.isMiss?"MISS":o.isStale?"STALE":"HIT"),b.setHeader(s.NEXT_IS_PRERENDER_HEADER,"1"));let{value:q}=o;if(as)n={revalidate:0,expire:void 0};else if(M&&an&&!am&&ap)n={revalidate:0,expire:void 0};else if(!J.isDev)if($)n={revalidate:0,expire:void 0};else if(ai){if(o.cacheControl)if("number"==typeof o.cacheControl.revalidate){if(o.cacheControl.revalidate<1)throw Object.defineProperty(Error(`Invalid revalidate configuration provided: ${o.cacheControl.revalidate} < 1`),"__NEXT_ERROR_CODE",{value:"E22",enumerable:!1,configurable:!0});n={revalidate:o.cacheControl.revalidate,expire:(null==(k=o.cacheControl)?void 0:k.expire)??ac.expireTime}}else n={revalidate:x.CACHE_ONE_YEAR,expire:void 0}}else b.getHeader("Cache-Control")||(n={revalidate:0,expire:void 0});if(o.cacheControl=n,"string"==typeof au&&(null==q?void 0:q.kind)===u.CachedRouteKind.APP_PAGE&&q.segmentData){b.setHeader(s.NEXT_DID_POSTPONE_HEADER,"2");let c=null==(m=q.headers)?void 0:m[x.NEXT_CACHE_TAGS_HEADER];M&&ai&&c&&"string"==typeof c&&b.setHeader(x.NEXT_CACHE_TAGS_HEADER,c);let d=q.segmentData.get(au);return void 0!==d?(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(d),cacheControl:o.cacheControl}):(b.statusCode=204,(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(""),cacheControl:o.cacheControl}))}let r=(0,h.getRequestMeta)(a,"onCacheEntry");if(r&&await r({...o,value:{...o.value,kind:"PAGE"}},{url:(0,h.getRequestMeta)(a,"initURL")}))return null;if(p&&as)throw Object.defineProperty(Error("Invariant: postponed state should not be present on a resume request"),"__NEXT_ERROR_CODE",{value:"E396",enumerable:!1,configurable:!0});if(q.headers){let a={...q.headers};for(let[c,d]of(M&&ai||delete a[x.NEXT_CACHE_TAGS_HEADER],Object.entries(a)))if(void 0!==d)if(Array.isArray(d))for(let a of d)b.appendHeader(c,a);else"number"==typeof d&&(d=d.toString()),b.appendHeader(c,d)}let t=null==(i=q.headers)?void 0:i[x.NEXT_CACHE_TAGS_HEADER];if(M&&ai&&t&&"string"==typeof t&&b.setHeader(x.NEXT_CACHE_TAGS_HEADER,t),!q.status||an&&ap||(b.statusCode=q.status),!M&&q.status&&E.RedirectStatusCode[q.status]&&an&&(b.statusCode=200),p&&b.setHeader(s.NEXT_DID_POSTPONE_HEADER,"1"),an&&!$){if(void 0===q.rscData){if(q.postponed)throw Object.defineProperty(Error("Invariant: Expected postponed to be undefined"),"__NEXT_ERROR_CODE",{value:"E372",enumerable:!1,configurable:!0});return(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:q.html,cacheControl:at?{revalidate:0,expire:void 0}:o.cacheControl})}return(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(q.rscData),cacheControl:o.cacheControl})}let v=q.html;if(!p||M)return(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:o.cacheControl});if(aq)return v.chain(new ReadableStream({start(a){a.enqueue(y.ENCODED_TAGS.CLOSED.BODY_AND_HTML),a.close()}})),(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:{revalidate:0,expire:void 0}});let A=new TransformStream;return v.chain(A.readable),f({span:d,postponed:q.postponed,fallbackRouteParams:null}).then(async a=>{var b,c;if(!a)throw Object.defineProperty(Error("Invariant: expected a result to be returned"),"__NEXT_ERROR_CODE",{value:"E463",enumerable:!1,configurable:!0});if((null==(b=a.value)?void 0:b.kind)!==u.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant: expected a page response, got ${null==(c=a.value)?void 0:c.kind}`),"__NEXT_ERROR_CODE",{value:"E305",enumerable:!1,configurable:!0});await a.value.html.pipeTo(A.writable)}).catch(a=>{A.writable.abort(a).catch(a=>{console.error("couldn't abort transformer",a)})}),(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:{revalidate:0,expire:void 0}})};if(!aD)return await aC.withPropagatedContext(a.headers,()=>aC.trace(i.BaseServerSpan.handleRequest,{spanName:`${aB} ${a.url}`,kind:g.SpanKind.SERVER,attributes:{"http.method":aB,"http.target":a.url}},n));await n(aD)}catch(b){throw aD||await J.onRequestError(a,b,{routerKind:"App Router",routePath:B,routeType:"render",revalidateReason:(0,f.c)({isRevalidate:ai,isOnDemandRevalidate:af})},ab),b}}},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64799:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>g});var d=c(60687),e=c(43210),f=c(37590);function g(){let[a,b]=(0,e.useState)({fullName:"",dateOfBirth:"",email:"",mobileNumber:"",gender:"",occupation:"",idType:"",idNumber:"",issuedAuthority:"",issuedPlace:"",issuedDate:"",expiryDate:""}),[c,g]=(0,e.useState)({}),[h,i]=(0,e.useState)(!1),[j,k]=(0,e.useState)(!1),l=a=>{let{name:c,value:d}=a.target;b(a=>({...a,[c]:d})),g(a=>({...a,[c]:""}))},m=async b=>{if(b.preventDefault(),!(()=>{let b={};return a.fullName.trim()||(b.fullName="Full Name is required"),a.dateOfBirth||(b.dateOfBirth="Date of Birth is required"),a.email?/^\S+@\S+\.\S+$/.test(a.email)||(b.email="Email format is invalid"):b.email="Email is required",a.mobileNumber.trim()||(b.mobileNumber="Mobile Number is required"),a.gender||(b.gender="Please select gender"),a.occupation.trim()||(b.occupation="Occupation is required"),a.idType||(b.idType="Please select ID Type"),a.idNumber.trim()||(b.idNumber="ID Number is required"),a.issuedAuthority.trim()||(b.issuedAuthority="Issued Authority is required"),a.issuedPlace.trim()||(b.issuedPlace="Issued Place is required"),a.issuedDate||(b.issuedDate="Issued Date is required"),a.expiryDate||(b.expiryDate="Expiry Date is required"),a.issuedDate&&a.expiryDate&&new Date(a.expiryDate)<=new Date(a.issuedDate)&&(b.expiryDate="Expiry Date must be after Issued Date"),g(b),0===Object.keys(b).length})())return void f.Ay.error("Please fix the errors in the form");i(!0),k(!1);try{let b=await fetch("/api/registrations",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...a,dateOfBirth:new Date(a.dateOfBirth),issuedDate:new Date(a.issuedDate),expiryDate:new Date(a.expiryDate)})});if(b.ok)k(!0),f.Ay.success("Registration successful!");else{let{message:a}=await b.json();f.Ay.error(a||"Registration failed")}}catch{f.Ay.error("An error occurred during registration")}finally{i(!1)}},n="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300";return(0,d.jsxs)("div",{className:"max-w-4xl mx-auto p-8 bg-white rounded-2xl shadow-lg mt-16 mb-8",children:[(0,d.jsx)(f.l$,{position:"top-center",toastOptions:{style:{background:"#363636",color:"#fff"},success:{iconTheme:{primary:"#10B981",secondary:"#fff"}},error:{iconTheme:{primary:"#EF4444",secondary:"#fff"}}}}),(0,d.jsx)("h2",{className:"text-3xl font-bold text-center text-sky-500 mb-6",children:"Registration Form"}),j&&(0,d.jsx)("div",{className:"mb-6 p-4 text-green-800 bg-green-100 rounded-lg text-center font-semibold",children:"Registration successful!"}),(0,d.jsxs)("form",{onSubmit:m,className:"grid grid-cols-1 md:grid-cols-2 gap-4",noValidate:!0,children:[(0,d.jsx)("h3",{className:"col-span-full text-lg font-semibold text-gray-700",children:"Personal Details"}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"fullName",placeholder:"Full Name",value:a.fullName,onChange:l,className:`${n} ${c.fullName?"border-red-500":"border-gray-300"}`,required:!0}),c.fullName&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.fullName})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"date",name:"dateOfBirth",value:a.dateOfBirth,onChange:l,className:`${n} ${c.dateOfBirth?"border-red-500":"border-gray-300"}`,required:!0}),c.dateOfBirth&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.dateOfBirth})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"email",name:"email",placeholder:"Email",value:a.email,onChange:l,className:`${n} ${c.email?"border-red-500":"border-gray-300"}`,required:!0}),c.email&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.email})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"mobileNumber",placeholder:"Mobile Number",value:a.mobileNumber,onChange:l,className:`${n} ${c.mobileNumber?"border-red-500":"border-gray-300"}`,required:!0}),c.mobileNumber&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.mobileNumber})]}),(0,d.jsxs)("div",{children:[(0,d.jsxs)("select",{name:"gender",value:a.gender,onChange:l,className:`${n} ${c.gender?"border-red-500":"border-gray-300"}`,required:!0,children:[(0,d.jsx)("option",{value:"",children:"Select Gender"}),(0,d.jsx)("option",{children:"Male"}),(0,d.jsx)("option",{children:"Female"}),(0,d.jsx)("option",{children:"Other"})]}),c.gender&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.gender})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"occupation",placeholder:"Occupation",value:a.occupation,onChange:l,className:`${n} ${c.occupation?"border-red-500":"border-gray-300"}`,required:!0}),c.occupation&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.occupation})]}),(0,d.jsx)("h3",{className:"col-span-full text-lg font-semibold text-gray-700 mt-4",children:"Identity Details"}),(0,d.jsxs)("div",{children:[(0,d.jsxs)("select",{name:"idType",value:a.idType,onChange:l,className:`${n} ${c.idType?"border-red-500":"border-gray-300"}`,required:!0,children:[(0,d.jsx)("option",{value:"",children:"Select ID Type"}),(0,d.jsx)("option",{children:"Passport"}),(0,d.jsx)("option",{children:"National ID"}),(0,d.jsx)("option",{children:"Driver’s License"})]}),c.idType&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.idType})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"idNumber",placeholder:"ID Number",value:a.idNumber,onChange:l,className:`${n} ${c.idNumber?"border-red-500":"border-gray-300"}`,required:!0}),c.idNumber&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.idNumber})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"issuedAuthority",placeholder:"Issued Authority",value:a.issuedAuthority,onChange:l,className:`${n} ${c.issuedAuthority?"border-red-500":"border-gray-300"}`,required:!0}),c.issuedAuthority&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.issuedAuthority})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"text",name:"issuedPlace",placeholder:"Issued Place",value:a.issuedPlace,onChange:l,className:`${n} ${c.issuedPlace?"border-red-500":"border-gray-300"}`,required:!0}),c.issuedPlace&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.issuedPlace})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"date",name:"issuedDate",value:a.issuedDate,onChange:l,className:`${n} ${c.issuedDate?"border-red-500":"border-gray-300"}`,required:!0}),c.issuedDate&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.issuedDate})]}),(0,d.jsxs)("div",{children:[(0,d.jsx)("input",{type:"date",name:"expiryDate",value:a.expiryDate,onChange:l,className:`${n} ${c.expiryDate?"border-red-500":"border-gray-300"}`,required:!0}),c.expiryDate&&(0,d.jsx)("p",{className:"text-red-500 text-sm mt-1",children:c.expiryDate})]}),(0,d.jsx)("div",{className:"col-span-full mt-4",children:(0,d.jsx)("button",{type:"submit",disabled:h,className:`w-full py-3 bg-sky-500 text-white rounded-lg cursor-pointer hover:bg-sky-600 transition ${h?"opacity-50 cursor-not-allowed":""}`,children:h?"Submitting...":"Next"})})]})]})}},82658:(a,b,c)=>{Promise.resolve().then(c.bind(c,64799))},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},92341:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>d});let d=(0,c(61369).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Getahun\\\\Desktop\\\\projects\\\\kidney\\\\app\\\\registration\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Getahun\\Desktop\\projects\\kidney\\app\\registration\\page.tsx","default")}};var b=require("../../webpack-runtime.js");b.C(a);var c=b.X(0,[4985,5329,9698],()=>b(b.s=45524));module.exports=c})();