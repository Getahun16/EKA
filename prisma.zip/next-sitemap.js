module.exports = {
  siteUrl: "https://ethiopiankidneyassociation.et",
  generateRobotsTxt: true,
  sitemapSize: 7000,
};
